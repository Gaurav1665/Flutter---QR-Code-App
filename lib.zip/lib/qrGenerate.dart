import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/rendering.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:qrgen/qrVersionSegmentedButton.dart';
import 'package:share_plus/share_plus.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'dart:typed_data';
import 'dart:ui' as ui;

class QrGenerateScreen extends StatefulWidget {
  const QrGenerateScreen({Key? key}) : super(key: key);

  @override
  State<QrGenerateScreen> createState() => _QrGenerateScreenState();
}

class _QrGenerateScreenState extends State<QrGenerateScreen> {
  final TextEditingController _textController = TextEditingController();
  String _qrData = '';
  final GlobalKey _repaintBoundaryKey = GlobalKey();
  QrCode? _qrCode;
  int _selectedQrVersion = 2;

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  void _generateQr() {
    setState(() {
      _qrData = _textController.text.trim();
      if(_qrData.isNotEmpty) 
        _qrCode = QrCode.fromData(data: _qrData, errorCorrectLevel: QrErrorCorrectLevel.M);
      else
        _qrCode = null;
    });
  }

  Future<void> _shareQr() async {
    print(_qrCode);
    if (_qrData.isEmpty || _qrCode == null) return;
    final QrExportFormat? selectedFormat = await _showFormatSelectionDialog();

    if (selectedFormat == null) return;

    try {
      RenderRepaintBoundary boundary = _repaintBoundaryKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
      
      ui.Image image = await boundary.toImage(pixelRatio: 3.0);
      
      Uint8List bytes;
      String fileName = 'qr_code${selectedFormat.extension}';
      String mimeType = selectedFormat.mimeType;

      switch (selectedFormat) {
        case QrExportFormat.png:
          ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);
          bytes = byteData!.buffer.asUint8List();
          break;
        
        case QrExportFormat.pdf:
          bytes = await _createPdfWithQr(image);
          break;
      }
      
      // Save to temporary file and share
      await Share.shareXFiles([
        XFile.fromData(
          bytes,
          name: fileName,
          mimeType: mimeType,
        )
      ]);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error sharing QR code: $e')),
      );
    }
  }

  Future<QrExportFormat?> _showFormatSelectionDialog() async {
    return showDialog<QrExportFormat>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Select Export Format'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: QrExportFormat.values.map((format) {
              return ListTile(
                leading: Icon(_getFormatIcon(format)),
                title: Text(format.displayName),
                subtitle: Text(_getFormatDescription(format)),
                onTap: () => Navigator.of(context).pop(format),
              );
            }).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  IconData _getFormatIcon(QrExportFormat format) {
    switch (format) {
      case QrExportFormat.png:
        return Icons.image;
      case QrExportFormat.pdf:
        return Icons.picture_as_pdf;
    }
  }

  String _getFormatDescription(QrExportFormat format) {
    switch (format) {
      case QrExportFormat.png:
        return 'High quality with transparency';
      case QrExportFormat.pdf:
        return 'Document format';
    }
  }

  Future<Uint8List> _createPdfWithQr(ui.Image qrImage) async {
    final pdf = pw.Document();
    
    // Convert ui.Image to bytes for PDF
    final ByteData? byteData = await qrImage.toByteData(format: ui.ImageByteFormat.png);
    final Uint8List imageBytes = byteData!.buffer.asUint8List();
    
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Center(
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text(
                  'QR Code',
                  style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold),
                ),
                pw.SizedBox(height: 20),
                pw.Container(
                  width: 200,
                  height: 200,
                  child: pw.Image(
                    pw.MemoryImage(imageBytes),
                    fit: pw.BoxFit.contain,
                  ),
                ),
                pw.SizedBox(height: 20),
                pw.Container(
                  padding: const pw.EdgeInsets.all(10),
                  decoration: pw.BoxDecoration(
                    border: pw.Border.all(color: PdfColors.grey),
                    borderRadius: pw.BorderRadius.circular(5),
                  ),
                  child: pw.Text(
                    _qrData,
                    style: const pw.TextStyle(fontSize: 12),
                    textAlign: pw.TextAlign.center,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
    
    return await pdf.save();
  }

  void _copyToClipboard() {
    if (_qrData.isNotEmpty) {
      Clipboard.setData(ClipboardData(text: _qrData));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Text copied to clipboard'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Generate QR Code'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Enter Text or URL:',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _textController,
                      decoration: InputDecoration(
                        hintText: 'Enter text or URL (e.g., https://example.com)',
                        border: const OutlineInputBorder(),
                        contentPadding: const EdgeInsets.all(12),
                        suffixIcon: _textController.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  _textController.clear();
                                  setState(() {
                                    _qrData = '';
                                    _qrCode = null;
                                  });
                                },
                              )
                            : null,
                      ),
                      onChanged: (value) {
                        setState(() {}); // Rebuild to update clear button
                      },
                    ),
                    const SizedBox(height: 16),
                    
                    QrVersionSegmentedButton(
                      selectedVersion: _selectedQrVersion,
                      onVersionChanged: (version) {
                        setState(() {
                          _selectedQrVersion = version;
                        });
                      },
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _generateQr,
                        icon: const Icon(Icons.qr_code),
                        label: const Text('Generate QR Code'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 20),
            if (_qrData.isNotEmpty) ...[
              Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'Generated QR Code',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.all(16),
                        child: RepaintBoundary(
                          key: _repaintBoundaryKey,
                          child: SizedBox(
                            width: 200,
                            height: 200,
                            child: QrImageView(
                              data: _qrData,
                              version: _selectedQrVersion,
                              size: 200,
                              backgroundColor: Colors.white,
                              errorCorrectionLevel: QrErrorCorrectLevel.M,
                              padding: const EdgeInsets.all(16),
                            )
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      // Display the QR data with scrollable text if long
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: Text(
                          _qrData,
                          style: const TextStyle(
                            fontSize: 14,
                            fontFamily: 'monospace',
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Action buttons
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        alignment: WrapAlignment.center,
                        children: [
                          ElevatedButton.icon(
                            onPressed: _shareQr,
                            icon: const Icon(Icons.share, size: 18),
                            label: const Text('Share'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 8,
                              ),
                            ),
                          ),
                          ElevatedButton.icon(
                            onPressed: _copyToClipboard,
                            icon: const Icon(Icons.copy, size: 18),
                            label: const Text('Copy'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 8,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

enum QrExportFormat {
  png('PNG', 'image/png', '.png'),
  pdf('PDF', 'application/pdf', '.pdf');

  const QrExportFormat(this.displayName, this.mimeType, this.extension);
  final String displayName;
  final String mimeType;
  final String extension;
}