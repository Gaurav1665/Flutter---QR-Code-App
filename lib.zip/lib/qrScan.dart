import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:url_launcher/url_launcher.dart';

class QrScanScreen extends StatefulWidget {
  const QrScanScreen({Key? key}) : super(key: key);

  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> {
  MobileScannerController cameraController = MobileScannerController();
  String? scannedData;
  bool isScanning = true;
  bool isFlashOn = false;

  @override
  void dispose() {
    cameraController.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (!isScanning) return;

    final List<Barcode> barcodes = capture.barcodes;
    if (barcodes.isNotEmpty) {
      final String? code = barcodes.first.rawValue;
      if (code != null && code.isNotEmpty) {
        setState(() {
          scannedData = code;
          isScanning = false;
        });
        _showResultDialog(code);
      }
    }
  }

  void _showResultDialog(String result) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('QR Code Scanned'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Scanned Data:'),
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: SelectableText(
                  result,
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: result));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Copied to clipboard')),
                );
              },
              child: const Text('Copy'),
            ),
            if (_isUrl(result))
              TextButton(
                onPressed: () => _launchUrl(result),
                child: const Text('Open URL'),
              ),
            TextButton(
              onPressed: () {
                _resetScanner;
                Navigator.of(context).pop();
              },
              child: const Text('Close'),
            ),
          ],

        );
      },
    );
  }

  bool _isUrl(String text) {
    text = text.trim();
    if (text.startsWith('http://') || text.startsWith('https://')) {
      return true;
    }
    if (text.contains('.') && !text.contains(' ')) {
      return true;
    }
    return false;
  }

  Future<void> _launchUrl(String url) async {
    try {
      String urlToLaunch = url.trim();
      
      if (!urlToLaunch.startsWith('http://') && !urlToLaunch.startsWith('https://')) {
        urlToLaunch = 'https://$urlToLaunch';
      }
      
      final Uri uri = Uri.parse(urlToLaunch);
      
      await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
    } catch (e) {
      try {
        String urlToLaunch = url.trim();
        if (!urlToLaunch.startsWith('http://') && !urlToLaunch.startsWith('https://')) {
          urlToLaunch = 'https://$urlToLaunch';
        }
        final Uri uri = Uri.parse(urlToLaunch);
        await launchUrl(uri, mode: LaunchMode.platformDefault);
      } catch (e2) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not launch URL: ${e2}')),
        );
      }
    }
  }

  void _resetScanner() {
    setState(() {
      scannedData = null;
      isScanning = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan QR Code'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Expanded(
            flex: 4,
            child: Stack(
              children: [
                MobileScanner(
                  controller: cameraController,
                  onDetect: _onDetect,
                ),
                // Overlay with scanning area
                Container(
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                  ),
                  child: Stack(
                    children: [
                      // Scanning area cutout
                      Center(
                        child: Container(
                          width: 250,
                          height: 250,
                          child: Stack(
                            children: [
                              // Corner decorations
                              Positioned(
                                top: 0,
                                left: 0,
                                child: Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    border: Border(
                                      top: BorderSide(color: Colors.blue, width: 4),
                                      left: BorderSide(color: Colors.blue, width: 4),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                top: 0,
                                right: 0,
                                child: Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    border: Border(
                                      top: BorderSide(color: Colors.blue, width: 4),
                                      right: BorderSide(color: Colors.blue, width: 4),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 0,
                                left: 0,
                                child: Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    border: Border(
                                      bottom: BorderSide(color: Colors.blue, width: 4),
                                      left: BorderSide(color: Colors.blue, width: 4),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    border: Border(
                                      bottom: BorderSide(color: Colors.blue, width: 4),
                                      right: BorderSide(color: Colors.blue, width: 4),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      // Instructions
                      const Positioned(
                        bottom: 100,
                        left: 0,
                        right: 0,
                        child: Text(
                          'Position QR code within the frame',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}