import 'package:flutter/material.dart';

class QrVersionSegmentedButton extends StatefulWidget {
  final int selectedVersion;
  final Function(int) onVersionChanged;

  const QrVersionSegmentedButton({
    Key? key,
    required this.selectedVersion,
    required this.onVersionChanged,
  }) : super(key: key);

  @override
  State<QrVersionSegmentedButton> createState() => _QrVersionSegmentedButtonState();
}

class _QrVersionSegmentedButtonState extends State<QrVersionSegmentedButton> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'QR Code Version:',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        SegmentedButton<int>(
          segments: const [
            ButtonSegment(value: 2, label: Text('Small')),
            ButtonSegment(value: 5, label: Text('Medium')),
            ButtonSegment(value: 10, label: Text('Large')),
          ],
          selected: {widget.selectedVersion},
          onSelectionChanged: (Set<int> newSelection) {
            widget.onVersionChanged(newSelection.first);
          },
          showSelectedIcon: false,
          style: SegmentedButton.styleFrom(
            elevation: 0,
            selectedBackgroundColor: Colors.blue,
            selectedForegroundColor: Colors.white
          ),
        ),
      ],
    );
  }
}